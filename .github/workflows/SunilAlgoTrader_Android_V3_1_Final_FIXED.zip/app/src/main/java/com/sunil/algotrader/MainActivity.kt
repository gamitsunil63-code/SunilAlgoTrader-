package com.sunil.algotrader

import android.app.*
import android.os.*
import android.content.*
import android.util.Base64
import android.view.*
import android.widget.*
import org.json.*
import java.net.HttpURLConnection
import java.net.URL
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import java.security.KeyStore
import kotlin.concurrent.thread
import kotlin.math.*

data class Candle(val t:Long,val o:Double,val h:Double,val l:Double,val c:Double,val v:Double)

data class Signal(val side:String,val score:Int,val price:Double,val support:Double,val resistance:Double,val reason:String)

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var signal: TextView
    private lateinit var stats: TextView
    private lateinit var pairInput: EditText
    private lateinit var capitalSpinner: Spinner
    private lateinit var riskInput: EditText
    private lateinit var customCapitalInput: EditText
    private lateinit var leverageInput: EditText
    private lateinit var modeSpinner: Spinner
    private lateinit var apiKeyInput: EditText
    private lateinit var apiSecretInput: EditText
    private var running=false
    private var balance=10000.0
    private var entry=0.0
    private var sl=0.0
    private var tp=0.0
    private var qty=0.0
    private var side=""
    private var wins=0
    private var trades=0
    private var net=0.0
    private var livePositionId=""
    private val handler=Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("secure_settings", MODE_PRIVATE) }
    private val keystoreAlias="SunilAlgoTraderKey"

    override fun onCreate(b:Bundle?) {
        super.onCreate(b)
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,20,20,20) }
        fun tv(s:String,size:Float=16f)=TextView(this).apply{text=s;textSize=size;setPadding(0,7,0,7)}
        root.addView(tv("SUNIL ALGO TRADER V3",24f))
        root.addView(tv("15m • Paper + CoinDCX Live",15f))
        status=tv("Status: OFF",18f); root.addView(status)
        val scroll=ScrollView(this); val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        pairInput=EditText(this).apply{setText("B-ETH_USDT");hint="CoinDCX Futures Pair"}; box.addView(pairInput)
        box.addView(tv("Chart: 15 minutes"))
        capitalSpinner=Spinner(this); capitalSpinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("₹5,000","₹10,000","₹15,000","₹20,000","₹25,000","₹50,000","Custom")); box.addView(capitalSpinner)
        customCapitalInput=EditText(this).apply{setText("10000");hint="Custom capital (₹)";inputType=2}; box.addView(customCapitalInput)
        modeSpinner=Spinner(this); modeSpinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("PAPER MODE","LIVE MODE")); box.addView(modeSpinner)
        riskInput=EditText(this).apply{setText("1.0");hint="Risk % per trade"}; box.addView(riskInput)
        leverageInput=EditText(this).apply{setText("5");hint="Leverage (LIVE)"}; box.addView(leverageInput)
        box.addView(tv("Strategy: EMA 21/50 • RSI reversal 20–30 / 70–80 • CHoCH • BOS • Support/Resistance • MACD • Volume • CHOP • Confluence Score"))
        apiKeyInput=EditText(this).apply{hint="CoinDCX API Key (Live only)"; inputType=1}; box.addView(apiKeyInput)
        apiSecretInput=EditText(this).apply{hint="CoinDCX API Secret (Live only)"; inputType=129}; box.addView(apiSecretInput)
        loadSecrets()
        val save=Button(this).apply{text="SAVE API SETTINGS";setOnClickListener{saveSecrets();toast("API settings saved securely on this phone")}}; box.addView(save)
        val test=Button(this).apply{text="TEST COINDCX CONNECTION";setOnClickListener{testConnection()}}; box.addView(test)
        signal=tv("Signal: WAITING",20f); box.addView(signal)
        stats=tv("Capital: ₹10,000\nPosition: NONE\nP&L: ₹0\nTrades: 0 | Wins: 0"); box.addView(stats)
        val start=Button(this).apply{text="START PAPER / LIVE";setOnClickListener{startAlgo()}}
        val stop=Button(this).apply{text="STOP ALGO";setOnClickListener{stopAlgo()}}
        val reset=Button(this).apply{text="RESET PAPER";setOnClickListener{resetPaper()}}
        box.addView(start);box.addView(stop);box.addView(reset)
        box.addView(tv("LIVE safety: use a trading-only API key, disable withdrawal permission, and never share the secret. Live orders are real money."))
        scroll.addView(box); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f)); setContentView(root)
    }

    private fun selectedCapital():Double = when(capitalSpinner.selectedItemPosition){0->5000.0;1->10000.0;2->15000.0;3->20000.0;4->25000.0;5->50000.0;else->(customCapitalInput.text.toString().toDoubleOrNull()?:10000.0).coerceAtLeast(500.0)}

    private fun startAlgo(){
        if(running)return
        if(modeSpinner.selectedItemPosition==1){
            if(apiKeyInput.text.toString().trim().isEmpty() || apiSecretInput.text.toString().trim().isEmpty()){toast("Enter CoinDCX API key and secret first");return}
            AlertDialog.Builder(this).setTitle("REAL MONEY LIVE MODE").setMessage("This will place real CoinDCX Futures orders when the strategy triggers. Use a trading-only API key. Start only if you understand the risk.")
                .setNegativeButton("CANCEL",null).setPositiveButton("START LIVE"){_,_->saveSecrets();balance=selectedCapital();running=true;status.text="Status: LIVE RUNNING";loop()}.show()
        } else { balance=selectedCapital();running=true;status.text="Status: PAPER RUNNING";loop() }
    }

    private fun stopAlgo(){running=false;status.text="Status: OFF"}
    private fun resetPaper(){running=false;balance=selectedCapital();entry=0.0;sl=0.0;tp=0.0;qty=0.0;side="";wins=0;trades=0;net=0.0;livePositionId="";signal.text="Signal: WAITING";updateStats(0.0)}

    private fun loop(){
        if(!running)return
        thread {
            try{
                val p=pairInput.text.toString().trim()
                val txt=URL("https://public.coindcx.com/market_data/candles?pair=$p&interval=15m&limit=140").readText()
                val a=JSONArray(txt); val cs=mutableListOf<Candle>()
                for(i in 0 until a.length()){val x=a.getJSONArray(i);cs.add(Candle(x.getLong(0),x.getDouble(1),x.getDouble(2),x.getDouble(3),x.getDouble(4),x.getDouble(5)))}
                cs.sortBy{it.t}; val closes=cs.map{it.c}; val price=closes.last(); val r=rsi(closes,14); val prevR=rsi(closes.dropLast(1),14)
                val ema21=ema(closes,21); val ema50=ema(closes,50); val mac=macd(closes); val prevMac=macd(closes.dropLast(1))
                val recent=cs.takeLast(12); val support=recent.minOf{it.l}; val resistance=recent.maxOf{it.h}; val atr=atr(cs,14)
                val prevHigh=cs.dropLast(1).takeLast(10).maxOf{it.h}; val prevLow=cs.dropLast(1).takeLast(10).minOf{it.l}
                val bullishChoch=price>recent.dropLast(1).maxOf{it.h} && r>prevR
                val bearishChoch=price<recent.dropLast(1).minOf{it.l} && r<prevR
                val bosLong=price>prevHigh; val bosShort=price<prevLow
                val nearSupport=price<=support+atr*1.25; val nearResistance=price>=resistance-atr*1.25
                val volumeOk=cs.last().v >= cs.takeLast(20).map{it.v}.average()*0.8
                val chop=atr/price < 0.004 && abs(ema21-ema50)/price < 0.002
                val longScore=listOf(ema21>ema50,r<=30.0&&r>prevR,bullishChoch,bosLong,nearSupport,mac>prevMac,volumeOk,!chop).count{it}
                val shortScore=listOf(ema21<ema50,r>=70.0&&r<prevR,bearishChoch,bosShort,nearResistance,mac<prevMac,volumeOk,!chop).count{it}
                val sig=if(longScore>=5 && !chop) Signal("LONG",longScore,price,support,resistance,"RSI reversal + structure/trend confirmation") else if(shortScore>=5 && !chop) Signal("SHORT",shortScore,price,support,resistance,"RSI reversal + structure/trend confirmation") else Signal("WAIT",max(longScore,shortScore),price,support,resistance,if(chop)"CHOP FILTER" else "Waiting for confluence")
                val liveMode=modeSpinner.selectedItemPosition==1
                runOnUiThread{signal.text="Price: ${"%.4f".format(sig.price)}\n${sig.side} • Score ${sig.score}/8\nSupport: ${"%.4f".format(sig.support)}  Resistance: ${"%.4f".format(sig.resistance)}\nRSI: ${"%.1f".format(r)} • EMA21: ${"%.4f".format(ema21)} • EMA50: ${"%.4f".format(ema50)}"}
                if(side.isEmpty() && sig.side!="WAIT") openPosition(sig.side,price,liveMode)
                if(side.isNotEmpty()) manage(price,liveMode)
            }catch(e){runOnUiThread{status.text="Status: ERROR • ${e.message?.take(80) ?: "market data"}"}}
            handler.postDelayed({loop()},15000)
        }
    }

    private fun openPosition(s:String,p:Double,live:Boolean){
        val riskPct=(riskInput.text.toString().toDoubleOrNull()?:1.0)/100.0; val risk=balance*riskPct; val dist=p*0.01
        qty=min(risk/dist,balance*(leverageInput.text.toString().toDoubleOrNull()?:5.0)*0.9/p)
        if(qty<=0)return
        entry=p;side=s;sl=if(s=="LONG")p-dist else p+dist;tp=if(s=="LONG")p+dist*2 else p-dist*2
        if(live){
            val result=placeLiveOrder(s,p,qty)
            if(!result.first){side="";entry=0.0;toast("LIVE order failed: ${result.second}");return}
            Thread.sleep(800)
            val pos=findLivePositionId()
            if(pos.isEmpty()){ side=""; entry=0.0; toast("Live entry sent, but position ID was not found. Check CoinDCX positions."); return }
            livePositionId=pos
            createLiveTPSL(livePositionId,sl,tp,s)
            runOnUiThread{status.text="Status: LIVE • $s ORDER SENT"}
        } else runOnUiThread{status.text="Status: PAPER • $s OPEN"}
    }

    private fun manage(p:Double,live:Boolean){
        val pnl=if(side=="LONG")(p-entry)*qty else(entry-p)*qty
        val hit=(side=="LONG"&&p<=sl)||(side=="SHORT"&&p>=sl)||(side=="LONG"&&p>=tp)||(side=="SHORT"&&p<=tp)
        runOnUiThread{updateStats(pnl)}
        if(hit){
            if(live && livePositionId.isNotEmpty()){
                val r=exitLivePosition(livePositionId)
                if(!r.first){toast("LIVE exit failed: ${r.second}");return}
            }
            balance+=pnl;net+=pnl;trades++;if(pnl>0)wins++;side="";entry=0.0;sl=0.0;tp=0.0;qty=0.0;livePositionId=""
        }
    }

    private fun updateStats(openPnl:Double=0.0){stats.text="Capital: ₹${"%.0f".format(balance)}\nPosition: ${if(side.isEmpty())"NONE" else "$side @ ${"%.4f".format(entry)} | SL ${"%.4f".format(sl)} | TP ${"%.4f".format(tp)}"}\nOpen P&L: ₹${"%.2f".format(openPnl)}\nNet P&L: ₹${"%.2f".format(net)}\nTrades: $trades | Wins: $wins"}

    private fun testConnection(){thread{try{val key=apiKeyInput.text.toString().trim();val sec=apiSecretInput.text.toString().trim();if(key.isEmpty()||sec.isEmpty()){toast("Enter API key and secret");return@thread};val body="{\"timestamp\":${System.currentTimeMillis()},\"page\":\"1\",\"size\":\"5\",\"margin_currency_short_name\":[\"USDT\"]}";val r=privatePost("/exchange/v1/derivatives/futures/positions",body,key,sec);toast(if(r.first)"CoinDCX connection OK" else "Connection failed: ${r.second.take(120)}")}catch(e:Exception){toast("Connection failed: ${e.message}")}}}

    private fun placeLiveOrder(s:String,p:Double,q:Double):Pair<Boolean,String>{return try{val key=apiKeyInput.text.toString().trim();val sec=apiSecretInput.text.toString().trim();val lev=leverageInput.text.toString().toDoubleOrNull()?:5.0;val sideApi=if(s=="LONG")"buy" else "sell";val body="{\"timestamp\":${System.currentTimeMillis()},\"order\":{\"side\":\"$sideApi\",\"pair\":\"${pairInput.text.toString().trim()}\",\"order_type\":\"market_order\",\"price\":\"${"%.8f".format(p)}\",\"stop_price\":\"0\",\"total_quantity\":${"%.8f".format(q)},\"leverage\":${"%.2f".format(lev)},\"notification\":\"no_notification\",\"hidden\":false,\"post_only\":false,\"margin_currency_short_name\":[\"USDT\"]}}";val r=privatePost("/exchange/v1/derivatives/futures/orders/create",body,key,sec);if(!r.first)Pair(false,r.second)else{val arr=JSONArray(r.second);Pair(true,arr.getJSONObject(0).optString("id"))}}catch(e:Exception){Pair(false,e.message ?: "error")}}

    private fun findLivePositionId():String{
        return try{
            val key=apiKeyInput.text.toString().trim(); val sec=apiSecretInput.text.toString().trim();
            val pair=pairInput.text.toString().trim();
            val body="{\"timestamp\":${System.currentTimeMillis()},\"page\":\"1\",\"size\":\"10\",\"pairs\":\"$pair\",\"margin_currency_short_name\":[\"USDT\"]}"
            val r=privatePost("/exchange/v1/derivatives/futures/positions",body,key,sec);
            if(!r.first) return "";
            val arr=JSONArray(r.second); if(arr.length()==0) return "";
            arr.getJSONObject(0).optString("id")
        }catch(_:Exception){""}
    }

    private fun createLiveTPSL(id:String,stop:Double,target:Double,s:String){thread{try{val key=apiKeyInput.text.toString().trim();val sec=apiSecretInput.text.toString().trim();val body="{\"timestamp\":${System.currentTimeMillis()},\"id\":\"$id\",\"take_profit\":{\"stop_price\":\"${"%.8f".format(target)}\",\"order_type\":\"take_profit_market\"},\"stop_loss\":{\"stop_price\":\"${"%.8f".format(stop)}\",\"order_type\":\"stop_market\"}}";val r=privatePost("/exchange/v1/derivatives/futures/positions/create_tpsl",body,key,sec);if(!r.first)toast("TP/SL setup failed: ${r.second.take(100)}") }catch(e:Exception){toast("TP/SL error: ${e.message}")}}}

    private fun exitLivePosition(id:String):Pair<Boolean,String>{return try{val key=apiKeyInput.text.toString().trim();val sec=apiSecretInput.text.toString().trim();val body="{\"timestamp\":${System.currentTimeMillis()},\"id\":\"$id\"}";privatePost("/exchange/v1/derivatives/futures/positions/exit",body,key,sec)}catch(e:Exception){Pair(false,e.message ?: "error")}}

    private fun privatePost(path:String,body:String,key:String,secret:String):Pair<Boolean,String>{val sig=hmac(body,secret);val c=(URL("https://api.coindcx.com$path").openConnection() as HttpURLConnection);c.requestMethod="POST";c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("X-AUTH-APIKEY",key);c.setRequestProperty("X-AUTH-SIGNATURE",sig);c.doOutput=true;c.connectTimeout=10000;c.readTimeout=10000;c.outputStream.use{it.write(body.toByteArray())};val code=c.responseCode;val stream=if(code in 200..299)c.inputStream else c.errorStream;val text=stream?.bufferedReader()?.readText() ?: "";Pair(code in 200..299,text)}
    private fun hmac(body:String,secret:String):String{val mac=Mac.getInstance("HmacSHA256");mac.init(SecretKeySpec(secret.toByteArray(),"HmacSHA256"));return mac.doFinal(body.toByteArray()).joinToString(""){String.format("%02x",it)}}

    private fun saveSecrets(){prefs.edit().putString("key",encrypt(apiKeyInput.text.toString())).putString("secret",encrypt(apiSecretInput.text.toString())).apply()}
    private fun loadSecrets(){apiKeyInput.setText(decrypt(prefs.getString("key","")?:""));apiSecretInput.setText(decrypt(prefs.getString("secret","")?:""))}
    private fun cryptoKey():javax.crypto.SecretKey{val ks=KeyStore.getInstance("AndroidKeyStore").apply{load(null)};if(!ks.containsAlias(keystoreAlias)){val kg=javax.crypto.KeyGenerator.getInstance("AES","AndroidKeyStore");kg.init(android.security.keystore.KeyGenParameterSpec.Builder(keystoreAlias,android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or android.security.keystore.KeyProperties.PURPOSE_DECRYPT).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE).build());kg.generateKey()};return (ks.getEntry(keystoreAlias,null) as KeyStore.SecretKeyEntry).secretKey}
    private fun encrypt(s:String):String{if(s.isEmpty())return "";val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,cryptoKey());return Base64.encodeToString(c.iv+c.doFinal(s.toByteArray()),Base64.NO_WRAP)}
    private fun decrypt(s:String):String{if(s.isEmpty())return "";return try{val raw=Base64.decode(s,Base64.NO_WRAP);val iv=raw.copyOfRange(0,12);val data=raw.copyOfRange(12,raw.size);val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,cryptoKey(),javax.crypto.spec.GCMParameterSpec(128,iv));String(c.doFinal(data))}catch(_:Exception){""}}

    private fun ema(x:List<Double>,n:Int):Double{var e=x.take(n).average();for(v in x.drop(n))e=v*(2.0/(n+1))+e*(1-2.0/(n+1));return e}
    private fun rsi(x:List<Double>,n:Int):Double{if(x.size<=n)return 50.0;var g=0.0;var l=0.0;for(i in 1..n){val d=x[i]-x[i-1];if(d>=0)g+=d else l-=d};g/=n;l/=n;for(i in n+1 until x.size){val d=x[i]-x[i-1];g=(g*(n-1)+max(d,0.0))/n;l=(l*(n-1)+max(-d,0.0))/n};return if(l==0.0)100.0 else 100-100/(1+g/l)}
    private fun macd(x:List<Double>):Double=ema(x,12)-ema(x,26)
    private fun atr(cs:List<Candle>,n:Int):Double{val tr=cs.zipWithNext().map{(a,b)->max(b.h-b.l,max(abs(b.h-a.c),abs(b.l-a.c)))};return tr.takeLast(n).average()}
    private fun toast(s:String){runOnUiThread{Toast.makeText(this,s,Toast.LENGTH_LONG).show()}}
}
