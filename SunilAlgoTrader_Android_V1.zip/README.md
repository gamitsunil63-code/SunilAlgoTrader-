# Sunil Algo Trader — Android V1

Android Studio project for a mobile-friendly paper-trading UI.

V1 includes:
- ETH/ZEC dashboard cards
- Pair/timeframe setup
- EMA, RSI, MACD, BOS/CHoCH, Fibonacci, Volume, CHOP filter switches
- Risk ₹ field
- Start/Stop Paper Algo buttons

No live CoinDCX API keys or real orders are included.

Open this folder in Android Studio and build an APK:
Build > Build App Bundle(s) / APK(s) > Build APK(s)

Next version will connect this UI to the Python backend and CoinDCX API.
