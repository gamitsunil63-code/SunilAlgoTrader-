package com.sunil.algotrader

import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.view.ViewGroup

class MainActivity : android.app.Activity() {
    private lateinit var status: TextView

    private fun dp(v:Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(Color.rgb(16,19,24))
        }
        scroll.addView(root)

        fun title(text:String, size:Float=22f): TextView =
            TextView(this).apply {
                this.text=text
                setTextColor(Color.WHITE)
                textSize=size
                setPadding(0, dp(8), 0, dp(8))
            }

        fun card(label:String, value:String): LinearLayout {
            val box=LinearLayout(this).apply {
                orientation=LinearLayout.VERTICAL
                setPadding(dp(14),dp(12),dp(14),dp(12))
                setBackgroundColor(Color.rgb(26,31,39))
            }
            val a=TextView(this).apply { text=label; textSize=12f; setTextColor(Color.LTGRAY) }
            val b=TextView(this).apply { text=value; textSize=19f; setTextColor(Color.WHITE); setPadding(0,dp(4),0,0) }
            box.addView(a); box.addView(b)
            return box
        }

        root.addView(title("📈 Sunil Algo Trader", 24f))
        root.addView(title("Android V1 • PAPER TRADING", 13f))

        root.addView(card("Algo Status", "🔴 OFF").apply {
            layoutParams=LinearLayout.LayoutParams(-1, dp(75)).apply { bottomMargin=dp(10) }
        })

        val grid=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        val eth=card("ETHUSDT", "WAITING")
        val zec=card("ZECUSDT", "NO TRADE")
        grid.addView(eth, LinearLayout.LayoutParams(0,dp(90),1f).apply{rightMargin=dp(5)})
        grid.addView(zec, LinearLayout.LayoutParams(0,dp(90),1f).apply{leftMargin=dp(5)})
        root.addView(grid)

        root.addView(title("⚙️ Strategy Setup", 19f))

        val pair=EditText(this).apply { hint="Pair (e.g. B-ETH_USDT)"; setText("B-ETH_USDT"); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) }
        root.addView(pair, LinearLayout.LayoutParams(-1,dp(55)))

        val tf=Spinner(this)
        tf.adapter=ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, arrayOf("15m","1H","5m"))
        root.addView(tf, LinearLayout.LayoutParams(-1,dp(55)))

        val ema=EditText(this).apply { hint="EMA Fast / Slow"; setText("21 / 50"); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) }
        val rsi=EditText(this).apply { hint="RSI minimum"; setText("50"); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) }
        root.addView(ema, LinearLayout.LayoutParams(-1,dp(55)))
        root.addView(rsi, LinearLayout.LayoutParams(-1,dp(55)))

        val checks = arrayOf("EMA 21/50","RSI","MACD","BOS / CHoCH","Fibonacci","Volume","CHOP Filter")
        for (c in checks) root.addView(CheckBox(this).apply {
            text=c; setTextColor(Color.WHITE); isChecked=true
        })

        val risk=EditText(this).apply { hint="Risk ₹ per trade"; setText("100"); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) }
        root.addView(risk, LinearLayout.LayoutParams(-1,dp(55)))

        status=title("Status: READY — Paper mode",16f)
        status.setTextColor(Color.YELLOW)
        root.addView(status)

        val start=Button(this).apply {
            text="START PAPER ALGO"
            setOnClickListener {
                status.text="Status: 🟢 PAPER ALGO RUNNING"
                Toast.makeText(this@MainActivity,"Paper Algo started",Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(start, LinearLayout.LayoutParams(-1,dp(55)))

        val stop=Button(this).apply {
            text="STOP ALGO"
            setOnClickListener {
                status.text="Status: 🔴 ALGO STOPPED"
                Toast.makeText(this@MainActivity,"Algo stopped",Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(stop, LinearLayout.LayoutParams(-1,dp(55)))

        root.addView(title("⚠️ Live API is not connected in V1.", 13f))
        root.addView(title("Next: CoinDCX backend → real market data → paper trades → risk engine → authenticated orders + SL/TP.", 12f))

        setContentView(scroll)
    }
}
