plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.sunil.algotrader"; compileSdk = 35
    defaultConfig { applicationId = "com.sunil.algotrader"; minSdk = 24; targetSdk = 35; versionCode = 3; versionName = "3.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_1_8; targetCompatibility = JavaVersion.VERSION_1_8 }
    kotlinOptions { jvmTarget = "1.8" }
}
