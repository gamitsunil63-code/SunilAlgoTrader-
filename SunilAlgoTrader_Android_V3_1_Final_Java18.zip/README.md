# Sunil Algo Trader V3.1

Android app for 15-minute strategy monitoring with Paper Trading and CoinDCX Futures Live mode.

## Strategy
- EMA 21/50
- RSI reversal: LONG 20–30, SHORT 70–80
- CHoCH + BOS
- Support / Resistance
- MACD + volume confirmation
- CHOP filter
- 8-point confluence score; entry at score >= 5

## Capital
Preset: ₹5k / ₹10k / ₹15k / ₹20k / ₹25k / ₹50k, plus Custom capital.

## Modes
- Paper mode uses a virtual balance.
- Live mode uses CoinDCX Futures API after explicit confirmation.
- API credentials are encrypted with Android Keystore on-device.

## Live safety
Use a dedicated trading API key, disable withdrawal permissions, and test Paper mode first. Live orders use real funds and can lose money.

## Important
This is an automation tool, not a profit guarantee. Market orders, slippage, fees, funding, liquidation, API/network failures and exchange rules can affect results.


## Build note
The Android project keeps Java/Kotlin target at 1.8 for compatibility. The GitHub Actions build must override both JavaCompile and KotlinCompile to JVM 17 before `assembleDebug`; this is the fix for the previous Java 1.8 vs Kotlin 17 validation error.
